"""Build the accompanying final-project report, AI declaration, contribution form and slides.
Requires python-docx and python-pptx on the DOCUMENT BUILDER machine, not for running the app.
"""
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor as DOC_RGB
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_BREAK
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pptx import Presentation
from pptx.util import Inches as PI, Pt as PP
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.enum.dml import MSO_THEME_COLOR
import json

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT/'docs'
ASSETS=ROOT/'assets'
results = json.loads((ROOT/'examples'/'default_result.json').read_text())
NAVY = (11,34,50); TEAL=(4,166,139); BLUE=(62,122,164); LIGHT=(239,247,249); GREY=(97,119,131); WHITE=(255,255,255); AMBER=(221,167,73)


def d_color(rgb):return DOC_RGB(*rgb)

def doc_setup(doc):
    for sec in doc.sections:
        sec.top_margin=Inches(.68);sec.bottom_margin=Inches(.56)
        sec.left_margin=Inches(.85);sec.right_margin=Inches(.85)
    styles=doc.styles
    normal=styles['Normal'];normal.font.name='Aptos';normal.font.size=Pt(9.3);normal.font.color.rgb=d_color(NAVY)
    normal.paragraph_format.space_after=Pt(5)
    for name,size,color in [('Title',28,NAVY),('Heading 1',16,NAVY),('Heading 2',12,TEAL)]:
        style=styles[name];style.font.name='Aptos Display';style.font.size=Pt(size);style.font.bold=True;style.font.color.rgb=d_color(color)
        style.paragraph_format.space_before=Pt(10);style.paragraph_format.space_after=Pt(4)
    header=doc.sections[0].header
    p=header.paragraphs[0];p.text='PARKPILOT  /  AI FUNDAMENTALS FINAL PROJECT'
    p.style='Normal';p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for r in p.runs:r.font.size=Pt(8);r.font.bold=True;r.font.color.rgb=d_color(GREY)
    footer=doc.sections[0].footer.paragraphs[0];footer.text='Educational simulation  •  All sensor inputs and parameters are hypothetical'
    footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for r in footer.runs:r.font.size=Pt(8);r.font.color.rgb=d_color(GREY)


def para(doc, txt, *, boldlead=None):
    p=doc.add_paragraph()
    if boldlead and txt.startswith(boldlead):
        p.add_run(boldlead).bold=True;p.add_run(txt[len(boldlead):])
    else:p.add_run(txt)
    return p


def bullet(doc,txt):
    p=doc.add_paragraph(style='List Bullet');p.add_run(txt);return p


def table(doc,headers,rows,widths=None):
    t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1';t.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(headers):t.rows[0].cells[i].text=h
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row):cells[i].text=str(v)
    for c in t.rows[0].cells:
        for p in c.paragraphs:
            for r in p.runs:r.font.bold=True
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths):row.cells[i].width=Inches(w)
    return t


def page(doc):doc.add_page_break()


def create_report():
    doc=Document();doc_setup(doc)
    p=doc.add_paragraph();p.space_before=Pt(28)
    p.add_run('AI FUNDAMENTALS  /  FINAL PROJECT').bold=True
    for r in p.runs:r.font.size=Pt(10);r.font.color.rgb=d_color(TEAL)
    p=doc.add_paragraph(style='Title');p.add_run('ParkPilot\nExplainable Smart Parking Guide')
    p=doc.add_paragraph('An interactive three-map prototype integrating BFS, Bayesian inference and a one-step Markov Decision Process.');p.style='Subtitle'
    table(doc,['PROJECT DETAILS','DESCRIPTION'],[
        ['Course','AIF1303 — AI Fundamentals'],['Student / Team','[Fill in your name(s) and group]'],
        ['Academic year','2026–2027'],['Platform','Python 3.9+, browser interface, local API'],
        ['Data policy','Synthetic inputs; no real users or sensors']])
    doc.add_paragraph('Application preview',style='Heading 2')
    doc.add_picture(str(ASSETS/'dashboard_top.png'),width=Inches(5.90))
    p=doc.add_paragraph('Figure 1. ParkPilot v5 interface: map switcher and three independent algorithm buttons.');p.style='Caption'
    page(doc)
    doc.add_heading('1. Problem and objectives',0)
    para(doc,'Problem. Drivers can waste time following stale or noisy indications of parking availability. A simple route alone is not enough: the destination may be occupied by the time the vehicle arrives. A decision support system must account for path distance and uncertainty.')
    para(doc,'Objective. Build one small, reproducible AI teaching prototype that (1) computes an optimal route on an unweighted grid, (2) estimates parking occupancy after noisy sensor evidence, and (3) chooses a risk-aware next action. The system displays the intermediate steps to support explanation during a live defense.')
    doc.add_heading('2. Scope, inputs and architecture',0)
    bullet(doc,'Three distinct 5 × 5 layouts: Mall, Campus and Stadium. Each has different start, blocked cells, parking-bay positions, initial sensor signals and prior occupancy probabilities. Mall example: start (4,0); obstacles (1,1), (2,1), (3,3); A (0,0), B (0,4), C (3,4).')
    bullet(doc,'For the Mall scenario: prior occupied probability A=0.25, B=0.45, C=0.60; initial readings CLEAR, ALERT, CLEAR. Campus and Stadium use their own values.')
    bullet(doc,'Noisy sensor: sensitivity P(ALERT | occupied)=0.85; specificity P(CLEAR | free)=0.90.')
    bullet(doc,'MDP: states FREE/OCCUPIED; actions DRIVE/RECHECK; two hypothetical transition distributions and state-specific reward values per action. Discount γ=0.60.')
    para(doc,'Integration pipeline: for each spot, BFS returns its route and distance → Bayes updates occupancy after the sensor observation → a one-step Bellman MDP evaluates DRIVE versus RECHECK → among reachable spots whose best MDP action is DRIVE, select the maximum (expected DRIVE utility − 0.70 × route steps). If none qualify, suggest RECHECK.')
    doc.add_heading('3. Algorithm 1 — Breadth-First Search',0)
    para(doc,'Purpose. Find the shortest walkable route from the car entry to a selected parking spot. The grid is an unweighted graph: each accessible cell is a node and each four-direction movement is an edge.')
    para(doc,'Process. Place the start in a FIFO queue. Repeatedly remove a cell, inspect its up/right/down/left neighbors, skip blocked or visited cells and record each newly visited cell’s predecessor. Once the goal is removed from the queue, trace predecessors backward to reconstruct the path.')
    para(doc,'Correctness. In an unweighted graph, BFS explores paths in nondecreasing step count, so the first discovered goal has minimum length. Runtime is O(V+E), and memory is O(V). For Mall, Spot A is 4 steps from the entry. Campus A is 4 steps and Stadium A is 5 steps; routing recomputes from each map’s entrance.')
    doc.add_heading('4. Algorithm 2 — Bayesian inference',0)
    para(doc,'Purpose. Update the chance that a spot is occupied after a sensor observation. Bayes’ theorem uses the prior P(O) and P(signal | O), P(signal | F).')
    para(doc,'P(O | signal) = P(signal | O)·P(O) / [P(signal | O)·P(O) + P(signal | F)·P(F)].')
    para(doc,'For Spot A with prior P(O)=0.25 and a CLEAR reading: P(CLEAR|O)=0.15, P(CLEAR|F)=0.90. Thus P(O|CLEAR)=0.0375/(0.0375+0.6750)=0.05263, or 5.3%. This is probabilistic inference with assumed parameters, not trained machine learning.')
    page(doc)
    doc.add_heading('5. Algorithm 3 — One-step MDP',0)
    para(doc,'Purpose. Decide whether to DRIVE to a spot or RECHECK the sensor under uncertainty. Each action has two state-specific rewards and two transition distributions. The discounted Bellman look-ahead is Q(s,a)=R(s,a)+γ Σₛ′ P(s′|s,a)V(s′).')
    table(doc,['Parameter','FREE state','OCCUPIED state'],[
        ['V(s), future state value','+4.0','−4.0'],['R(s, DRIVE)','+12.0','−12.0'],['R(s, RECHECK)','−2.0','−2.0'],
        ['P(FREE next | DRIVE)','0.95','0.10'],['P(FREE next | RECHECK)','0.85','0.35']])
    para(doc,'For each action, the state-specific Q values are mixed using the Bayesian posterior p=P(O|signal): E[Q(a)]=(1−p)Q(FREE,a)+pQ(OCCUPIED,a). The action with the greater expected Q value is recommended.')
    para(doc,'For default Spot A, Q(FREE, DRIVE)=14.16 and Q(OCCUPIED, DRIVE)=−13.92. With p=0.05263, expected DRIVE≈+12.68, while expected RECHECK≈−0.45. Therefore DRIVE is chosen. These utilities are arbitrary model points, not physical predictions.')
    doc.add_heading('6. Integration and implementation',0)
    para(doc,'The real algorithm implementations are in parking_ai.py; app.py exposes an HTTP API using Python’s ThreadingHTTPServer; web/index.html, styles.css and ui.js implement the interactive dashboard. The interface has three map choices (Mall / Campus / Stadium) and three independent algorithm buttons. The selected map is transmitted to every Python endpoint, so calculations use map-specific layout data. BFS calls /api/bfs to draw a route and animate the car; Bayes calls /api/bayes to estimate occupancy after a selectable sensor reading; MDP calls /api/mdp to compare DRIVE and RECHECK. A separate /api/analyze endpoint also supports integrated scenario evaluation. The implementation uses Python’s standard library only for the runtime, allowing an offline local demo.')
    table(doc,['Case','BFS distance','Posterior occupied','MDP action','DRIVE score'],[
        ['Spot A · CLEAR','4','5.3%','DRIVE','+9.88'],
        ['Spot B · ALERT','8','87.4%','RECHECK','−15.99'],
        ['Spot C · CLEAR','5','20.0%','DRIVE','+5.04']])
    para(doc,'Table 2. Mall default-case results. DRIVE score = expected DRIVE value − 0.70 × BFS distance. Spot B’s score is shown for transparency but is excluded from final DRIVE ranking because MDP chose RECHECK.')
    page(doc)
    doc.add_heading('7. Testing and results',0)
    para(doc,'Automated verification. We ran `python -m unittest discover -s tests -v`: all 25 tests passed. They cover shortest paths and obstacles on all nine target bays across three maps, Bayesian inference, MDP transitions/action switching, scenario differences and integrated recommendations.')
    para(doc,'HTTP and browser smoke checks. A real local HTTP GET returned all three map definitions, and 27 separate HTTP POST calls to /api/bfs, /api/bayes and /api/mdp returned valid results for the three maps and all nine target bays. A Chromium UI smoke test used a bridge to the same Python algorithm functions and verified all three map tabs, nine BFS/Bayes/MDP combinations, the animated car, the sensor change, the MDP decision, bay selection, mobile layout and reset, without JavaScript errors. The real HTTP API and browser UI were tested separately; a live end-to-end browser/server test was not claimed.')
    table(doc,['Scenario','Input change','Observed recommendation','Interpretation'],[
        ['Default','A CLEAR; B ALERT; C CLEAR','DRIVE → A','Short route + low posterior occupancy'],
        ['Alternative','Change A to ALERT','DRIVE → C','Reacts to new risk evidence'],
        ['All alerts','Set A, B, C to ALERT','RECHECK → A','Avoids immediate driving in all-alert case']])
    doc.add_heading('8. Reliability, limitations and responsible AI',0)
    bullet(doc,'All prior probabilities, sensor accuracy, transition probabilities, rewards, discount factor and travel penalty are hypothetical. They are assumptions, not measured calibration.')
    bullet(doc,'All three grids are tiny and static. BFS assumes each step has equal cost; a real parking system needs current roads, traffic constraints and perhaps A* or Dijkstra.')
    bullet(doc,'The MDP performs a one-step Bellman update with fixed continuation values, not optimal value iteration or reinforcement learning. This meets the small-scale topic specification, but cannot guarantee long-term optimal control.')
    bullet(doc,'No actual location data, user identities, real sensors, trained models or external APIs are used. The app is for explanation, not driving decisions or operational safety.')
    para(doc,'Responsible AI use. Generative AI substantially assisted with the prototype, written report and presentation. This assistance must be disclosed in the accompanying AI Use Declaration, and the student must personally review all code, test claims, results and explanations before academic submission.')
    doc.add_heading('9. Conclusion and future work',0)
    para(doc,'ParkPilot demonstrates a meaningful sequence of three different AI approaches: deterministic search solves the spatial subproblem, Bayes solves uncertainty in perception, and the MDP makes an action choice. Reproducible cases show that changing one sensor reading can change the recommended parking space. Next steps could use calibrated sensors, real-time maps, time-dependent occupancy, extended value iteration and accessibility-aware routing.')
    doc.save(DOCS/'Technical_Report.docx')


def create_declaration():
    doc=Document();doc_setup(doc)
    doc.add_heading('AI Use Declaration',0)
    para(doc,'Course: AIF1303 AI Fundamentals  |  Assignment: Final Project — ParkPilot')
    para(doc,'Student name / group: [Enter your actual name and group]  |  Date: 22 November 2026')
    table(doc,['Required field','Accurate disclosure'],[
        ['AI tool','OpenAI ChatGPT (GPT-6), accessed through ChatGPT; 22 November 2026.'],
        ['Purpose','Develop project idea, explain three course algorithms, assist with Python/HTML/CSS/JavaScript implementation, tests, UI layout, technical writing, slide preparation and defense script.'],
        ['Key prompts','“Do the final project for me except the video”; requests for a clearer UI and two additional maps; assignment rubric and supplied guidelines.'],
        ['AI contribution','Substantial AI-assisted generation of code, test cases, design, documentation and presentation. Do not describe this work as independently authored without disclosing assistance.'],
        ['Verification already performed','25 unit/integration tests passed; 27 HTTP map-specific algorithm requests and Chromium UI smoke test passed. The UI browser test uses the same Python functions as the server and checks all three map tabs, clicks, sensor changes and animation.'],
        ['Verification you must perform','Run the project yourself, read and understand the BFS/Bayes/MDP functions, confirm visuals and report values, review slides, rehearse defense, and check academic-integrity rules with your instructor.'],
        ['Limitations','All probabilities, rewards and transitions are simulated. No external sources, datasets or experimental field accuracy are claimed.'],
    ])
    doc.add_heading('Student acknowledgment',1)
    para(doc,'I confirm that I have read and understood the project I submit, have verified the results and claims I rely on, and have accurately disclosed any substantive AI assistance. I remain responsible for academic integrity, accuracy and originality.')
    para(doc,'Signature: __________________________________   Date: _____________________')
    doc.save(DOCS/'AI_Use_Declaration.docx')


def create_team():
    doc=Document();doc_setup(doc)
    doc.add_heading('Team Contribution Statement',0)
    para(doc,'Project: ParkPilot — Explainable Smart Parking Guide  |  Course: AIF1303 AI Fundamentals')
    para(doc,'IMPORTANT: Fill in only verified, real personal contributions. Do not invent teammates or claim parts of AI-assisted generation as your independent coding.')
    doc.add_heading('If completed individually',1)
    table(doc,['Field','Enter truthfully'],[
        ['Student name / ID','[Your name and student number]'],
        ['Individual work personally completed','[e.g., testing, reading/adjusting code, running demo, checking calculations, editing report — include only what you actually did]'],
        ['AI assistance','ChatGPT substantially assisted in implementation and documentation; see AI Use Declaration.'],
        ['Code sections you can explain','[List modules you reviewed and can defend]'],
    ])
    doc.add_heading('If completed as a team (maximum 4)',1)
    table(doc,['Member name','Actual tasks completed','How contribution was checked'],[
        ['[Member 1]','[Only verified work]','[Evidence]'],['[Member 2]','[Only verified work]','[Evidence]'],
        ['[Member 3, if any]','[Only verified work]','[Evidence]'],['[Member 4, if any]','[Only verified work]','[Evidence]']])
    para(doc,'Each member must individually explain the algorithms and answer defense questions. Delete the section that does not apply.')
    para(doc,'Team confirmations / signatures: _____________________________________________')
    doc.save(DOCS/'Team_Contribution_Statement.docx')

# ------------------------------ PPTX ------------------------------
prs=Presentation();prs.slide_width=PI(13.333);prs.slide_height=PI(7.5)
BG=(240,247,250)

def col(c):return RGBColor(*c)

def shape(slide,x,y,w,h,fill,border=None,rounded=False):
    obj=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE,PI(x),PI(y),PI(w),PI(h))
    obj.fill.solid();obj.fill.fore_color.rgb=col(fill)
    if border:obj.line.color.rgb=col(border)
    else:obj.line.fill.background()
    return obj

def txt(slide,x,y,w,h,text,size=18,color=NAVY,bold=False,align=None,font='Aptos',valign=None):
    box=slide.shapes.add_textbox(PI(x),PI(y),PI(w),PI(h));tf=box.text_frame;tf.clear();tf.word_wrap=True
    tf.margin_left=PP(0);tf.margin_top=PP(0);tf.margin_right=PP(0);tf.margin_bottom=PP(0)
    for j,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if j==0 else tf.add_paragraph();p.text=line
        p.font.name=font;p.font.size=PP(size);p.font.bold=bold;p.font.color.rgb=col(color)
        if align:p.alignment=align
        p.space_after=PP(8)
    return box

def base_slide(k,title=None,eyebrow=None):
    slide=prs.slides.add_slide(prs.slide_layouts[6]);shape(slide,0,0,13.333,7.5,BG)
    shape(slide,0,0,13.333,.14,TEAL)
    if eyebrow:txt(slide,.65,.40,11,.32,eyebrow,12,TEAL,True)
    if title:txt(slide,.65,.86,11.9,.65,title,31,NAVY,True,'','Aptos Display')
    shape(slide,.65,7.13,12.05,.012,(204,221,229))
    txt(slide,.66,7.19,10,.20,'PARKPILOT  /  AI FUNDAMENTALS  /  EDUCATIONAL SIMULATION',8,GREY,True)
    txt(slide,12.1,7.14,.45,.23,f'{k:02}',10,TEAL,True,PP_ALIGN.RIGHT)
    return slide

def card(slide,x,y,w,h,title,subtitle=None,accent=TEAL):
    shape(slide,x,y,w,h,WHITE,(219,231,237),True)
    shape(slide,x,y,.085,h,accent)
    txt(slide,x+.24,y+.23,w-.48,.40,title,18,NAVY,True)
    if subtitle:txt(slide,x+.24,y+.79,w-.48,h-.93,subtitle,13,GREY)

def pill(slide,x,y,w,text,color=TEAL):
    shape(slide,x,y,w,.35,(219,246,240),None,True)
    txt(slide,x+.12,y+.07,w-.24,.20,text,9,color,True)

def create_slides():
    # 1 — cover
    s=prs.slides.add_slide(prs.slide_layouts[6]);shape(s,0,0,13.333,7.5,NAVY)
    shape(s,.69,.82,.11,.73,TEAL)
    txt(s,1.01,.86,6.1,.4,'AI FUNDAMENTALS  /  FINAL PROJECT',13,(90,236,197),True)
    txt(s,1.00,1.65,6.45,2.0,'PARKPILOT\nSMART PARKING GUIDE',34,WHITE,True,font='Aptos Display')
    txt(s,1.03,4.12,5.92,.9,'An explainable AI prototype combining shortest-path search, probabilistic inference and sequential decision making.',18,(182,212,221))
    for i,t in enumerate(('01  BFS','02  BAYES','03  MDP')):pill(s,1.0+i*1.55,5.66,1.32,t)
    shape(s,7.29,1.05,5.40,5.45,(22,55,69),None,True)
    s.shapes.add_picture(str(ASSETS/'slide_preview.png'),PI(7.57),PI(1.32),width=PI(4.86),height=PI(3.62))
    txt(s,7.65,5.42,4.8,.7,'LIVE SIMULATION  •  3 MAPS  •  BFS / BAYES / MDP',13,(181,229,222),True)
    txt(s,1.02,7.16,11,.22,'PROJECT PRESENTATION  •  2026–2027  •  STUDENT / TEAM: [FILL IN]',9,(159,187,196))
    # 2
    s=base_slide(2,'The problem & our AI pipeline','01  /  PROBLEM STATEMENT')
    card(s,.65,1.77,3.7,1.45,'THE PROBLEM','Parking spaces may be reported free even when they are occupied.')
    card(s,4.82,1.77,3.7,1.45,'THE GOAL','Recommend a reachable space while considering uncertainty and travel cost.')
    card(s,8.98,1.77,3.7,1.45,'THE SCOPE','3 different 5×5 parking maps, each with 3 spaces and hypothetical sensors.')
    methods=[('1','BFS','Shortest route\n& number of steps'),('2','BAYES','Revised occupied\nprobability'),('3','MDP','DRIVE vs RECHECK\nexpected utility')]
    for i,(n,h,b) in enumerate(methods):
        x=.65+i*4.17;shape(s,x,3.85,3.70,1.9,(15,52,71),None,True)
        txt(s,x+.25,4.06,.55,.5,n,25,(77,224,191),True)
        txt(s,x+.85,4.06,2.6,.45,h,19,WHITE,True)
        txt(s,x+.86,4.62,2.45,.75,b,14,(193,221,225))
        if i<2:txt(s,x+3.75,4.44,.42,.4,'→',23,TEAL,True)
    txt(s,.65,6.15,11.65,.45,'Integrated score: expected DRIVE utility − 0.70 × BFS distance (only when MDP recommends DRIVE).',17,NAVY,True)
    # 3 BFS
    s=base_slide(3,'01 — BFS finds the shortest route','02  /  SEARCH ALGORITHM')
    shape(s,.68,1.72,5.58,4.82,NAVY,None,True)
    s.shapes.add_picture(str(ASSETS/'map_detail.png'),PI(1.02),PI(2.33),width=PI(4.90),height=PI(3.43))
    txt(s,6.66,1.81,5.89,.72,'A transparent spatial planner',23,NAVY,True)
    for i,(head,body) in enumerate([('INPUT','Chosen 5×5 layout; entry, target bay and blocked cells.'),('KEY STEPS','FIFO queue → expand four neighbors → mark predecessor → backtrack.'),('OUTPUT','Default entry → Spot A: 4 steps; obstacle cells avoided.'),('GUARANTEE','A shortest path is found for equal-cost moves; O(V+E) time.')]):
        y=2.77+i*.84;pill(s,6.68,y,1.22,head)
        txt(s,8.00,y-.02,4.6,.66,body,15,NAVY)
    # 4 BAYES
    s=base_slide(4,'02 — Bayes handles noisy sensors','03  /  PROBABILISTIC REASONING')
    txt(s,.76,1.66,11.3,.45,'Update the probability that a spot is occupied after one imperfect sensor reading.',18,GREY)
    card(s,.79,2.35,5.60,3.63,'Spot A  ·  CLEAR reading')
    txt(s,1.08,3.11,2.9,.47,'25.0%',34,(81,130,146),True)
    txt(s,4.01,3.11,1.90,.46,'→  5.3%',28,TEAL,True)
    txt(s,1.12,3.75,4.85,.61,'Prior occupancy        →        Posterior occupancy',14,GREY)
    shape(s,1.10,4.53,4.87,.17,(219,234,237),None,True)
    shape(s,1.10,4.53,1.22,.17,(92,162,177),None,True)
    shape(s,1.10,4.99,.26,.17,TEAL,None,True)
    txt(s,1.10,5.41,5.0,.40,'P(O|clear) = 0.0375 / (0.0375 + 0.6750)',13,NAVY,True)
    card(s,6.78,2.35,5.57,3.63,'How it works')
    txt(s,7.08,3.08,4.8,.67,'Prior P(O) = 0.25',18,NAVY,True)
    txt(s,7.08,3.69,4.9,.65,'Sensor sensitivity = 85%\nSensor specificity = 90%',16,NAVY)
    txt(s,7.08,4.81,4.96,.81,'The result is a conditional probability, not a trained neural network.',16,GREY)
    # 5 MDP
    s=base_slide(5,'03 — The MDP chooses the next action','04  /  SEQUENTIAL DECISION MAKING')
    txt(s,.76,1.65,12,.46,'Two states (FREE / OCCUPIED) × two actions (DRIVE / RECHECK) + a one-step Bellman update.',18,GREY)
    shape(s,.76,2.31,11.78,1.0,(16,50,67),None,True)
    txt(s,1.12,2.53,10.9,.53,'Q(s,a) = R(s,a) + γ Σ P(s′|s,a)V(s′)    •    γ = 0.60',23,WHITE,True)
    card(s,.76,3.62,5.63,2.42,'DRIVE','Reach a spot now. Reward +12 if free, −12 if occupied.',TEAL)
    card(s,6.76,3.62,5.78,2.42,'RECHECK','Spend time to improve information. Immediate reward −2 in either state.',BLUE)
    pill(s,1.05,5.27,3.90,'SPOT A EXPECTED VALUE: +12.68')
    pill(s,7.07,5.27,4.05,'SPOT A EXPECTED VALUE: −0.45',BLUE)
    txt(s,.87,6.45,11.9,.44,'For Spot A, DRIVE wins; for high-occupancy Spot B, RECHECK wins. Reward values are teaching assumptions.',16,NAVY,True)
    # 6 tests
    s=base_slide(6,'A working application with tested scenarios','05  /  LIVE DEMO & RESULTS')
    shape(s,.70,1.63,6.32,4.93,WHITE,(218,232,239),True)
    for i,(name,desc) in enumerate([('mall','MALL • Direct access'),('campus','CAMPUS • New entry'),('stadium','STADIUM • Blocked centre')]):
        yy=1.83+i*1.49
        s.shapes.add_picture(str(ASSETS/f'map_{name}.png'),PI(.90),PI(yy),width=PI(2.15),height=PI(1.42))
        txt(s,3.28,yy+.15,3.50,.45,desc,15,NAVY,True)
        txt(s,3.28,yy+.62,3.3,.53,'All 3 algorithms work on this map',12,GREY)

    pill(s,7.36,1.79,2.30,'25 / 25 TESTS PASS')
    txt(s,7.36,2.38,5.00,.60,'Default scenario',20,NAVY,True)
    txt(s,7.38,2.87,4.70,.44,'A CLEAR → Drive to A (4 steps)',16,GREY)
    txt(s,7.36,3.61,4.90,.60,'Change one reading',20,NAVY,True)
    txt(s,7.38,4.09,4.75,.65,'A ALERT → Drive to C (5 steps)',16,GREY)
    txt(s,7.36,4.86,4.90,.60,'All readings ALERT',20,NAVY,True)
    txt(s,7.38,5.35,4.60,.44,'System chooses RECHECK',16,GREY)
    txt(s,.86,6.72,11.6,.36,'Python standard library runtime  •  3 maps  •  Independent AI endpoints  •  25 tests',14,NAVY,True)
    # 7
    s=base_slide(7,'What we demonstrated — and what comes next','06  /  CONCLUSION & LIMITATIONS')
    card(s,.75,1.69,5.60,3.83,'WHAT WORKS','BFS computes routes. Bayes responds to uncertain sensor readings. A one-step MDP compares actions. Their combined output changes when evidence changes.',TEAL)
    card(s,6.75,1.69,5.75,3.83,'WHAT IS NOT CLAIMED','The three maps and sensor probabilities are simulated. No real deployment, trained model, real dataset or measured real-world accuracy is claimed.',AMBER)
    shape(s,.75,5.82,11.75,.77,NAVY,None,True)
    txt(s,1.07,6.03,11,.44,'NEXT: real sensors  •  calibrated probabilities  •  larger road maps  •  value iteration',17,WHITE,True,PP_ALIGN.CENTER)
    txt(s,3.00,6.68,7.1,.33,'THANK YOU  /  QUESTIONS?',21,TEAL,True,PP_ALIGN.CENTER)
    prs.save(DOCS/'Presentation.pptx')

if __name__=='__main__':
    DOCS.mkdir(exist_ok=True)
    create_report();create_declaration();create_team();create_slides()
    for p in sorted(DOCS.iterdir()):print(p.name,p.stat().st_size)
