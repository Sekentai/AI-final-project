"""Three genuinely different layouts, each using all three algorithms."""
import unittest
from parking_ai import MAPS, map_catalog, get_map, analyze, bfs, bayesian_occupancy, one_step_mdp

class TestThreeMaps(unittest.TestCase):
    def test_three_distinct_layouts(self):
        self.assertEqual(len(MAPS),3)
        self.assertEqual(set(MAPS),{'mall','campus','stadium'})
        fingerprints={(m['start'],tuple(sorted(m['walls'])),tuple(v['position'] for v in m['spots'].values())) for m in MAPS.values()}
        self.assertEqual(len(fingerprints),3)

    def test_all_nine_bfs_paths_reachable_and_valid(self):
        for map_id,layout in MAPS.items():
            for spot,data in layout['spots'].items():
                with self.subTest(map=map_id,spot=spot):
                    other={info['position'] for n,info in layout['spots'].items() if n!=spot}
                    path,expanded=bfs(layout['start'],data['position'],layout['walls']|other)
                    self.assertIsNotNone(path)
                    self.assertEqual(path[0],layout['start'])
                    self.assertEqual(path[-1],data['position'])
                    self.assertEqual(len(path),len(set(path)))
                    self.assertTrue(all(p not in layout['walls']|other for p in path))
                    self.assertTrue(all(abs(a[0]-b[0])+abs(a[1]-b[1])==1 for a,b in zip(path,path[1:])))
                    self.assertGreater(len(expanded),0)

    def test_all_three_methods_run_per_map(self):
        for map_id in MAPS:
            result=analyze({'map':map_id})
            self.assertEqual(result['map'],map_id)
            for spot,item in result['spots'].items():
                self.assertIsNotNone(item['distance'])
                self.assertAlmostEqual(item['bayes']['posterior'],bayesian_occupancy(item['prior'],item['alert'])['posterior'])
                self.assertEqual(item['mdp']['action'],one_step_mdp(item['bayes']['posterior'])['action'])

    def test_map_specific_prior_and_sensor(self):
        self.assertNotEqual(analyze({'map':'mall'})['spots']['A']['prior'],analyze({'map':'campus'})['spots']['A']['prior'])
        self.assertNotEqual(analyze({'map':'campus'})['spots']['A']['alert'],analyze({'map':'stadium'})['spots']['A']['alert'])

    def test_invalid_map_rejected(self):
        for bad in ('invalid','',None,123):
            with self.subTest(map=bad), self.assertRaises(ValueError):get_map(bad)

    def test_public_catalog_consistent_with_analyze(self):
        for entry in map_catalog()['maps']:
            output=analyze({'map':entry['id']})
            self.assertEqual(entry['start'],output['start'])
            self.assertEqual(entry['walls'],output['walls'])
            for name,info in entry['spots'].items():
                self.assertEqual(info['position'],output['spots'][name]['position'])

if __name__=='__main__':unittest.main()
