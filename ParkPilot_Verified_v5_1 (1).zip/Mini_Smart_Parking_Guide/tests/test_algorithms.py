"""Run: python -m unittest discover -s tests -v"""
import unittest
from parking_ai import (bfs, bayesian_occupancy, one_step_mdp, analyze, GRID_SIZE,
                        START, WALLS, SPOTS, TRANSITIONS, DISCOUNT, STATE_VALUES)

class TestSearch(unittest.TestCase):
    def test_start_is_goal(self):
        path, expanded = bfs((2,2),(2,2),set())
        self.assertEqual(path, [(2,2)])
        self.assertEqual(len(expanded), 1)

    def test_shortest_path_on_empty_map(self):
        path, _ = bfs((0,0),(4,4),set())
        self.assertEqual(len(path)-1, 8)

    def test_cannot_walk_through_walls(self):
        for spot in SPOTS.values():
            path, _ = bfs(START,spot['position'])
            self.assertIsNotNone(path)
            self.assertTrue(all(p not in WALLS for p in path))
            for a,b in zip(path,path[1:]):
                self.assertEqual(abs(a[0]-b[0])+abs(a[1]-b[1]),1)

    def test_unreachable(self):
        path, visited = bfs((0,0),(1,1), {(0,1),(1,0)})
        self.assertIsNone(path)
        self.assertEqual(visited,[(0,0)])

    def test_out_of_bounds(self):
        self.assertEqual(bfs((-1,0),(0,0))[0],None)

class TestBayes(unittest.TestCase):
    def test_positive_sensor_posterior(self):
        result = bayesian_occupancy(.45,True)
        self.assertAlmostEqual(result['posterior'],(.45*.85)/(.45*.85+.55*.10),places=10)

    def test_negative_sensor_posterior(self):
        result = bayesian_occupancy(.25,False)
        self.assertAlmostEqual(result['posterior'],.0375/.7125,places=10)

    def test_no_signal_assumption(self):
        self.assertAlmostEqual(bayesian_occupancy(.7,True,.5,.5)['posterior'],.7)

    def test_invalid_prior(self):
        with self.assertRaises(ValueError):
            bayesian_occupancy(2,True)

    def test_impossible_observation(self):
        with self.assertRaises(ValueError):
            bayesian_occupancy(0, True, 1, 1)

class TestMDP(unittest.TestCase):
    def test_rows_sum_to_one(self):
        for a in TRANSITIONS.values():
            for row in a.values():
                self.assertAlmostEqual(sum(row.values()),1)

    def test_bellman_free_drive(self):
        result = one_step_mdp(0)
        self.assertAlmostEqual(result['state_action_values']['DRIVE']['FREE'],14.16)
        self.assertEqual(result['action'],'DRIVE')

    def test_occupied_recheck(self):
        self.assertEqual(one_step_mdp(1)['action'],'RECHECK')

    def test_expected_action_switches(self):
        self.assertGreater(one_step_mdp(.2)['expected']['DRIVE'],one_step_mdp(.2)['expected']['RECHECK'])
        self.assertLess(one_step_mdp(.9)['expected']['DRIVE'],one_step_mdp(.9)['expected']['RECHECK'])

class TestIntegration(unittest.TestCase):
    def test_default_recommendation_and_path(self):
        result = analyze()
        self.assertEqual(result['recommendation']['spot'],'A')
        self.assertEqual(result['recommendation']['action'],'DRIVE')
        self.assertEqual(result['spots']['A']['distance'],4)

    def test_switch_to_alternative_spot(self):
        result = analyze({'spots':{'A':{'alert':True}}})
        self.assertEqual(result['recommendation']['spot'],'C')

    def test_selected_spot_and_bayes(self):
        result = analyze({'selected':'B'})
        self.assertEqual(result['selected'],'B')
        self.assertGreater(result['spots']['B']['bayes']['posterior'],.8)
        self.assertEqual(result['spots']['B']['mdp']['action'],'RECHECK')

    def test_invalid_sensor(self):
        with self.assertRaises(ValueError):
            analyze({'spots':{'A':{'alert':'alert'}}})

    def test_all_sensors_alert_recheck(self):
        result = analyze({'spots':{s:{'alert':True} for s in SPOTS}})
        self.assertEqual(result['recommendation']['action'],'RECHECK')

if __name__ == '__main__': unittest.main()
