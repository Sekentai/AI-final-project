"""End-to-end API plus Chromium UI smoke test for all three maps.

Run: python tests/browser_smoke.py
Requires Playwright + Chromium only for QA; production app is dependency-free.
HTTP endpoints tested directly; browser graphics use an in-process Python bridge
because this isolated Chromium runtime blocks connections to localhost.
"""
import json, os, re, socket, sys
from pathlib import Path
from subprocess import Popen, DEVNULL
from time import sleep
from urllib.request import Request, urlopen
from shutil import which
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from parking_ai import MAPS,map_catalog,bfs,bayesian_occupancy,one_step_mdp

def backend(endpoint,payload):
    if endpoint=='maps': return map_catalog()
    m=payload.get('map','mall');layout=MAPS[m];spot=payload['spot'];info=layout['spots'][spot]
    if endpoint=='bfs':
        walls=layout['walls']|{v['position'] for k,v in layout['spots'].items() if k!=spot}
        path,visited=bfs(layout['start'],info['position'],walls)
        return {'algorithm':'BFS','spot':spot,'map':m,'start':list(layout['start']),'goal':list(info['position']),
                'path':[list(v) for v in path] if path else None,'distance':len(path)-1 if path else None,
                'visited_count':len(visited),'visited_order':[list(v) for v in visited]}
    if endpoint=='bayes':
        return {'algorithm':'Bayes','spot':spot,'map':m,'prior':payload['prior'],'alert':payload['alert'],
                **bayesian_occupancy(payload['prior'],payload['alert'])}
    if endpoint=='mdp':
        return {'algorithm':'MDP','spot':spot,'map':m,'prob_occupied':payload['prob_occupied'],
                **one_step_mdp(payload['prob_occupied'])}
    raise ValueError(endpoint)

with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
    sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
server=Popen([sys.executable,'app.py'],cwd=ROOT,env={**os.environ,'PARKING_PORT':str(port)},stdout=DEVNULL,stderr=DEVNULL)
try:
    for _ in range(50):
        try:
            with urlopen(f'http://127.0.0.1:{port}/api/maps',timeout=1) as res:
                maps=json.load(res)['maps'];assert len(maps)==3
            break
        except OSError:
            if server.poll() is not None:raise RuntimeError('Server exited')
            sleep(.15)
    else:raise RuntimeError('Server not ready')
    # Real HTTP calls to every independent endpoint on all maps.
    for map_id,layout in MAPS.items():
        for spot,info in layout['spots'].items():
            for endpoint,body in [
                ('bfs',{'spot':spot,'map':map_id}),
                ('bayes',{'spot':spot,'map':map_id,'prior':info['prior'],'alert':info['alert']}),
                ('mdp',{'spot':spot,'map':map_id,'prob_occupied':info['prior']})]:
                req=Request(f'http://127.0.0.1:{port}/api/{endpoint}',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
                with urlopen(req,timeout=3) as res:result=json.load(res)
                assert result['map']==map_id and result['spot']==spot,(endpoint,result)
                if endpoint=='bfs':assert result['distance'] is not None
    for bad in ['unknown']:
        try:
            req=Request(f'http://127.0.0.1:{port}/api/bfs',data=json.dumps({'map':bad,'spot':'A'}).encode(),headers={'Content-Type':'application/json'})
            urlopen(req,timeout=3);raise AssertionError('Expected invalid map rejection')
        except Exception as exc:
            from urllib.error import HTTPError
            assert isinstance(exc,HTTPError) and exc.code==400,exc

    html=(ROOT/'web/index.html').read_text()
    html=re.sub(r'<link rel="stylesheet" href="styles.css\?v=5">','',html)
    html=re.sub(r'<script src="ui.js\?v=5"></script>','',html)
    css=(ROOT/'web/styles.css').read_text()
    js=(ROOT/'web/ui.js').read_text()
    (ROOT/'assets').mkdir(exist_ok=True)
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,args=['--no-sandbox'],**({'executable_path':which('chromium')} if which('chromium') else {}))
        page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
        errors=[];calls=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.expose_function('pythonApi',lambda ep,body:backend(ep,body))
        page.set_content(html,wait_until='domcontentloaded')
        page.add_style_tag(content=css)
        # The Chromium sandbox disallows localhost, so bridge only browser fetch to the same Python algorithms.
        page.evaluate('''() => {window.fetch=async (url,options)=>{
            let ep=url.slice(5);let body=options?.body?JSON.parse(options.body):{};
            return {ok:true,json:async()=>window.pythonApi(ep,body)};
        };}''')
        page.add_script_tag(content=js)
        page.wait_for_function("document.querySelector('#engine-status').textContent === 'AI engine online'")
        assert page.locator('.parking-target').count()==3
        assert page.locator('.algorithm-btn').count()==3
        assert page.locator('.map-switch').count()==3
        for map_id,expected_name in [('mall','SHOPPING CENTRE'),('campus','UNIVERSITY CAMPUS'),('stadium','SPORTS ARENA')]:
            page.locator(f'[data-map="{map_id}"]').click()
            page.wait_for_function(f"document.querySelector('#map-message').textContent.includes('{MAPS[map_id]['name']}')")
            assert page.locator('.parking-target').count()==3
            assert page.locator('[data-map="'+map_id+'"]').get_attribute('aria-pressed')=='true'
            assert expected_name in page.locator('#scene-base').text_content()
            for spot in 'ABC':
                page.locator(f'[data-spot="{spot}"]').click()
                page.locator('[data-mode="bfs"]').click()
                page.wait_for_function('document.querySelector(".result-number")?.textContent.includes("steps")')
                assert page.locator('.route-line').count()==1
                page.locator('[data-mode="bayes"]').click()
                page.wait_for_function('document.querySelector(".result-number")?.textContent.includes("%")')
                page.locator('[data-mode="mdp"]').click()
                page.wait_for_function('document.querySelector(".result-header h3")?.textContent.includes("MDP")')
            page.locator('[data-spot="A"]').click()
            page.locator('[data-mode="bfs"]').click()
            page.wait_for_function('document.querySelector(".route-line")!==null')
            page.locator('.map-frame').screenshot(path=str(ROOT/'assets'/f'map_{map_id}.png'))
        page.locator('[data-map="mall"]').click()
        page.locator('[data-mode="bfs"]').click()
        page.wait_for_function("document.querySelector('.result-number')?.textContent.includes('4 steps')")
        page.locator('#drive-action').click()
        page.wait_for_timeout(420)
        assert 'translate(' in page.locator('.car-body').last.get_attribute('transform')
        page.wait_for_function("document.querySelector('#drive-action')?.disabled===false",timeout=12000)
        page.locator('[data-mode="bayes"]').click()
        page.wait_for_function("document.querySelector('.result-number')?.textContent.includes('5.3%')")
        page.locator('#sensor-alert').click()
        page.wait_for_function("document.querySelector('.result-number')?.textContent.includes('73.9%')")
        page.locator('[data-mode="mdp"]').click()
        page.wait_for_function("document.querySelector('.result-number')?.textContent.includes('Check again')")
        page.locator('[data-map="campus"]').click()
        assert page.locator('.empty-explanation').count()==1
        page.locator('[data-mode="bayes"]').click()
        page.wait_for_function("document.querySelector('.result-number')?.textContent.includes('93.3%')")
        page.locator('#reset-btn').click()
        assert page.locator('.empty-explanation').count()==1
        assert page.locator('[data-map="mall"]').get_attribute('aria-pressed')=='true'
        page.set_viewport_size({'width':390,'height':844})
        page.screenshot(path=str(ROOT/'assets'/'mobile_screenshot.png'),full_page=True)
        page.set_viewport_size({'width':1440,'height':900})
        page.locator('[data-mode="bfs"]').click()
        page.wait_for_function('document.querySelector(".route-line")!==null')
        page.evaluate('window.scrollTo(0,0)')
        page.screenshot(path=str(ROOT/'assets'/'dashboard_top.png'),full_page=False)
        page.screenshot(path=str(ROOT/'assets'/'dashboard_screenshot.png'),full_page=True)
        assert errors==[],errors
        browser.close()
    print('PASS: 27 map-specific API calls (3 maps × 3 spots × 3 algorithms); 3 map tabs; all 9 BFS/Bayes/MDP UI flows; movement, sensor, reset and mobile, no JS exceptions')
finally:
    server.terminate()
    try:server.wait(timeout=5)
    except Exception:server.kill()
