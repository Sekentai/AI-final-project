"""Start with: python app.py ; open http://127.0.0.1:8765 in a browser."""
import json
import mimetypes
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit
from parking_ai import analyze, bfs, bayesian_occupancy, one_step_mdp, get_map, map_catalog, SENSITIVITY, SPECIFICITY

BASE = Path(__file__).resolve().parent
WEB = BASE / 'web'
MIME_TYPES = {'.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8'}

class Handler(BaseHTTPRequestHandler):
    def _send_json(self, status, result):
        content = json.dumps(result, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self):
        endpoint = urlsplit(self.path).path
        if endpoint not in ('/api/analyze', '/api/bfs', '/api/bayes', '/api/mdp'):
            return self._send_json(404, {'error': 'Unknown endpoint'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size < 0 or size > 100_000:
                return self._send_json(413, {'error': 'Payload too large'})
            raw = self.rfile.read(size)
            payload = json.loads(raw) if raw else {}
            if not isinstance(payload, dict):
                raise ValueError('Expected a JSON object.')
            if endpoint == '/api/analyze':
                result = analyze(payload)
            else:
                map_id = payload.get('map', 'mall')
                layout = get_map(map_id)
                spots = layout['spots']
                spot = payload.get('spot', 'A')
                if spot not in spots:
                    raise ValueError('spot must be A, B or C')
                if endpoint == '/api/bfs':
                    other_spots = {d['position'] for name, d in spots.items() if name != spot}
                    goal = spots[spot]['position']
                    start = layout['start']
                    path, visited = bfs(start, goal, layout['walls'] | other_spots)
                    result = {
                        'algorithm': 'BFS', 'spot': spot, 'map': map_id, 'start': list(start), 'goal': list(goal),
                        'path': [list(node) for node in path] if path else None,
                        'distance': len(path) - 1 if path else None, 'visited_count': len(visited),
                        'visited_order': [list(node) for node in visited],
                    }
                elif endpoint == '/api/bayes':
                    prior = float(payload.get('prior', spots[spot]['prior']))
                    alert = payload.get('alert', spots[spot]['alert'])
                    if not isinstance(alert, bool):
                        raise ValueError('alert must be true or false')
                    result = {
                        'algorithm': 'Bayes', 'spot': spot, 'map': map_id, 'prior': prior,
                        'alert': alert, **bayesian_occupancy(prior, alert),
                        'sensitivity': SENSITIVITY, 'specificity': SPECIFICITY,
                    }
                else:
                    prob = float(payload.get('prob_occupied', spots[spot]['prior']))
                    result = {
                        'algorithm': 'MDP', 'spot': spot, 'map': map_id, 'prob_occupied': prob,
                        **one_step_mdp(prob),
                    }
            return self._send_json(200, result)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            return self._send_json(400, {'error': str(exc)})

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == '/api/maps':
            return self._send_json(200, map_catalog())
        if path == '/api/health':
            return self._send_json(200, {'status': 'ok'})
        if path == '/api/analyze':
            return self._send_json(200, analyze())
        requested = 'index.html' if path == '/' else path.lstrip('/')
        file_path = (WEB / requested).resolve()
        if not file_path.is_relative_to(WEB) or not file_path.is_file():
            return self._send_json(404, {'error': 'Not found'})
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', MIME_TYPES.get(file_path.suffix, mimetypes.guess_type(str(file_path))[0] or 'application/octet-stream'))
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

if __name__ == '__main__':
    host = os.getenv('PARKING_HOST', '127.0.0.1')
    port = int(os.getenv('PARKING_PORT', '8765'))
    with ThreadingHTTPServer((host, port), Handler) as server:
        print(f'Smart Parking Guide at http://{host}:{port}')
        print('Press Ctrl+C to stop.')
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('\nServer stopped.')
