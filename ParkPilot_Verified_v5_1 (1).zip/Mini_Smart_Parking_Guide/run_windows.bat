@echo off
setlocal
cd /d "%~dp0"
title ParkPilot AI Parking Demonstration
echo ==============================================
echo   PARKPILOT - INTERACTIVE AI PARKING DEMO
echo ==============================================
echo.
echo Keep this window OPEN while using the website.
echo Website: http://127.0.0.1:8765/
echo.
rem Open the website automatically after the local server has time to start.
start "" /min powershell -NoProfile -Command "Start-Sleep -Seconds 3; Start-Process 'http://127.0.0.1:8765/'"
where py >nul 2>&1
if not errorlevel 1 goto use_py
where python >nul 2>&1
if not errorlevel 1 goto use_python
echo ERROR: Python was not found.
echo Install Python 3.9 or later and enable Add Python to PATH.
pause
exit /b 1
:use_py
py -3 app.py
goto finished
:use_python
python app.py
:finished
if errorlevel 1 echo The server stopped with an error. Check if port 8765 is already in use.
echo.
echo The website is offline after this window closes.
pause
