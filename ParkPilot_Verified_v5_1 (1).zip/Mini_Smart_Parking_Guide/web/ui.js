'use strict';
// No fake algorithm output: every Run click calls its own Python endpoint.
const NS='http://www.w3.org/2000/svg';
const $=id=>document.getElementById(id);
const XY={x0:180,y0:131,dx:125,dy:91};
const modeName={bfs:'Breadth-First Search',bayes:'Bayesian Inference',mdp:'Markov Decision Process'};
let maps={}, mapId='mall', layout=null, params={}, bay='A', mode=null, lastBayes={}, sequence=0;
let car=null, motion=null, routeElement=null, lastBfs=null, animationToken=0;
const pct=x=>(100*x).toFixed(1)+'%';
const num=x=>Number(x).toFixed(2);
const calcNum=x=>Number(x).toFixed(10); // Avoid early rounding in displayed equations.
const coord=pair=>({x:XY.x0+pair[1]*XY.dx,y:XY.y0+pair[0]*XY.dy});
function svg(tag,attrs={},parent){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,String(v));if(parent)parent.appendChild(e);return e;}
function textAt(parent,x,y,content,options={}){const e=svg('text',{x,y,'font-family':'Arial, sans-serif','font-size':14,'font-weight':800,fill:'#e3eeed',...options},parent);e.textContent=content;return e;}
function drawCar(parent,x,y,angle=0,paint='blue',scale=1){const g=svg('g',{transform:`translate(${x} ${y}) rotate(${angle}) scale(${scale})`,class:paint==='blue'?'car-body':'parked-car'},parent);const fill=paint==='blue'?'url(#paint)':paint==='orange'?'#edac83':paint==='white'?'#e6e8e6':'#819ba2';svg('rect',{x:-19,y:-33,width:38,height:66,rx:10,fill,stroke:'#183c49','stroke-width':1.6},g);for(const wx of[-22,17])for(const wy of[-22,10])svg('rect',{x:wx,y:wy,width:5,height:14,rx:2,fill:'#253136'},g);svg('path',{d:'M-13 -20 L13 -20 L16 -7 L-16 -7 Z',fill:'#163f4b',stroke:'#90c1c6','stroke-width':1},g);svg('rect',{x:-14,y:6,width:28,height:14,rx:4,fill:'#31545d',stroke:'#a5c3c4','stroke-width':.7},g);for(const xx of[-13,6]){svg('rect',{x:xx,y:-32,width:8,height:3,rx:1,fill:'#fff4cf'},g);svg('rect',{x:xx,y:29,width:8,height:3,rx:1,fill:'#dc6d62'},g);}return g;}
function buildMap(){
  if(!layout)return;
  const base=$('scene-base');base.replaceChildren();
  const theme={mall:{grass:'#aab8aa',edge:'#405359',island:'#6c9078',title:'SHOPPING CENTRE',detail:'MALL PARKING'},campus:{grass:'#a7bdb0',edge:'#41575a',island:'#748f9c',title:'UNIVERSITY CAMPUS',detail:'CAMPUS PARKING'},stadium:{grass:'#acb3ac',edge:'#45565a',island:'#b3a17b',title:'SPORTS ARENA',detail:'EVENT PARKING'}}[mapId];
  svg('rect',{width:900,height:615,fill:theme.grass},base);
  svg('rect',{x:93,y:45,width:712,height:526,rx:15,fill:theme.edge,stroke:'#d0dbcf','stroke-width':9},base);
  svg('rect',{x:97,y:49,width:706,height:517,rx:12,fill:'url(#grain)'},base);
  svg('rect',{x:230,y:0,width:438,height:37,rx:5,fill:mapId==='stadium'?'#e5e2d9':'#e8e8df'},base);
  textAt(base,449,24,theme.title,{'text-anchor':'middle',fill:'#59716c','letter-spacing':'2','font-size':14});
  for(let c=0;c<5;c++){const x=XY.x0+c*XY.dx;svg('line',{x1:x,y1:100,x2:x,y2:520,stroke:'#b9d0c4',opacity:.27,'stroke-width':2,'stroke-dasharray':'6 18'},base);}
  for(let r=0;r<5;r++){const y=XY.y0+r*XY.dy;svg('line',{x1:135,y1:y,x2:730,y2:y,stroke:'#b9d0c4',opacity:.22,'stroke-width':2,'stroke-dasharray':'7 18'},base);}
  for(const cell of layout.walls){const {x,y}=coord(cell);
    if(mapId==='mall'){
      svg('rect',{x:x-39,y:y-34,width:78,height:68,rx:12,fill:'#91a69b',stroke:'#c2d0c0','stroke-width':3},base);
      svg('rect',{x:x-33,y:y-28,width:66,height:56,rx:11,fill:theme.island},base);
      for(const[dx,dy,r]of[[-13,-8,14],[15,2,13],[0,14,12]])svg('circle',{cx:x+dx,cy:y+dy,r,fill:'#467958'},base);
    } else if(mapId==='campus'){
      svg('rect',{x:x-37,y:y-31,width:74,height:62,rx:9,fill:'#708c99',stroke:'#bbd6d3','stroke-width':3},base);
      svg('rect',{x:x-29,y:y-24,width:58,height:48,rx:5,fill:'#5d7885'},base);
      svg('line',{x1:x-21,y1:y-13,x2:x+21,y2:y+13,stroke:'#d6e7e5','stroke-width':5,opacity:.75},base);
      svg('line',{x1:x+21,y1:y-13,x2:x-21,y2:y+13,stroke:'#d6e7e5','stroke-width':5,opacity:.75},base);
    } else {
      svg('rect',{x:x-42,y:y-29,width:84,height:58,rx:7,fill:'#a49475',stroke:'#e8dbc0','stroke-width':3},base);
      svg('path',{d:`M${x-30} ${y+21} l40 -42 M${x-4} ${y+25} l40 -42`,stroke:'#eee0b5','stroke-width':8,opacity:.85},base);
      textAt(base,x,y+5,'CLOSED',{'text-anchor':'middle',fill:'#fff8e8','font-size':11});
    }
  }
  // Cars parked on the external edge are decoration; they do not alter BFS graph cells.
  for(let i=0;i<6;i++){const x=220+i*94;svg('path',{d:`M${x-38} 565 V580 H${x+38} V565`,stroke:'#eaf3e7','stroke-width':3,fill:'none'},base);if(i%3!==2)drawCar(base,x,547,0,i%2?'white':'orange',.57);}
  const start=coord(layout.start);
  svg('rect',{x:start.x-47,y:start.y-43,width:94,height:86,rx:10,fill:'#4bdcb1',opacity:.11,stroke:'#91eed0','stroke-width':3,'stroke-dasharray':'5 8'},base);
  textAt(base,start.x,start.y+62,'START',{'text-anchor':'middle','font-size':15,fill:'#bbf7e3'});
  $('map-tag').textContent=`${theme.detail} • P${Object.keys(maps).indexOf(mapId)+1}`;
  drawBays();resetCar();
}
function drawBays(){if(!layout)return;const layer=$('scene-bays');layer.replaceChildren();for(const name of Object.keys(layout.spots)){const p=coord(layout.spots[name].position),signal=params[name].alert;const g=svg('g',{class:'parking-target',tabindex:0,role:'button','aria-label':`Choose parking space ${name}`},layer);svg('rect',{class:'bay-outline',x:p.x-44,y:p.y-39,width:88,height:78,rx:8,fill:signal?'#856355':'#356e63',stroke:bay===name?'#ffd36e':signal?'#edb18b':'#99dcc7','stroke-width':bay===name?5:3},g);svg('path',{d:`M${p.x-30} ${p.y-29} V${p.y+27} H${p.x+30} V${p.y-29}`,stroke:'#ebeee7','stroke-width':3,fill:'none'},g);if(signal)drawCar(g,p.x,p.y,0,'orange',.72);else textAt(g,p.x,p.y+5,'FREE?',{'text-anchor':'middle','font-size':13,fill:'#d7f9e8'});svg('rect',{x:p.x-27,y:p.y-64,width:54,height:22,rx:5,fill:bay===name?'#ffdb86':'#e8f6f0'},g);textAt(g,p.x,p.y-49,'SPACE '+name,{'text-anchor':'middle','font-size':10,fill:'#29515a'});svg('title',{},g).textContent=`Space ${name}. ${signal?'Alert':'Clear'} sensor. Click to select.`;g.addEventListener('click',()=>selectBay(name));g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectBay(name);}});}}
function resetCar(){if(!layout)return;const layer=$('car-layer');layer.replaceChildren();const p=coord(layout.start);car=drawCar(layer,p.x,p.y,0,'blue',.96);}
function roundedPath(path,radius=20){const pts=path.map(coord);if(!pts.length)return'';let d=`M${pts[0].x} ${pts[0].y}`;for(let i=1;i<pts.length-1;i++){const a=pts[i-1],p=pts[i],b=pts[i+1],v1={x:p.x-a.x,y:p.y-a.y},v2={x:b.x-p.x,y:b.y-p.y},l1=Math.hypot(v1.x,v1.y),l2=Math.hypot(v2.x,v2.y),cross=v1.x*v2.y-v1.y*v2.x;if(Math.abs(cross)<.01){d+=` L${p.x} ${p.y}`;continue;}const r=Math.min(radius,l1*.32,l2*.32);const x=p.x-v1.x/l1*r,y=p.y-v1.y/l1*r,u=p.x+v2.x/l2*r,v=p.y+v2.y/l2*r;d+=` L${x.toFixed(2)} ${y.toFixed(2)} Q${p.x} ${p.y} ${u.toFixed(2)} ${v.toFixed(2)}`;}const q=pts.at(-1);return d+` L${q.x} ${q.y}`;}
function clearMotion(){animationToken++;if(motion!==null)cancelAnimationFrame(motion);motion=null;$('route-layer').replaceChildren();resetCar();lastBfs=null;}
function drawRoute(path){const layer=$('route-layer');layer.replaceChildren();const d=roundedPath(path);svg('path',{d,class:'route-shadow'},layer);routeElement=svg('path',{d,class:'route-line'},layer);const end=coord(path.at(-1));svg('circle',{cx:end.x,cy:end.y,r:7,class:'route-end'},layer);}
function driveCar(){if(!lastBfs?.path)return;const token=++animationToken;const btn=$('drive-action');if(btn)btn.disabled=true;const len=routeElement.getTotalLength(),limit=params[bay].alert?Math.max(0,len-75):len;const duration=Math.max(2300,Math.min(6200,len*7));const start=performance.now();function frame(now){if(token!==animationToken)return;let t=Math.min(1,(now-start)/duration);let eased=t*t*(3-2*t);const d=limit*eased;const p=routeElement.getPointAtLength(d),prev=routeElement.getPointAtLength(Math.max(0,d-3)),next=routeElement.getPointAtLength(Math.min(len,d+3));const angle=Math.atan2(next.y-prev.y,next.x-prev.x)*180/Math.PI+90;car.setAttribute('transform',`translate(${p.x.toFixed(2)} ${p.y.toFixed(2)}) rotate(${angle.toFixed(1)}) scale(.96)`);if(t<1){motion=requestAnimationFrame(frame);}else{motion=null;const done=$('drive-action');if(done){done.disabled=false;done.textContent='↻ Replay route';}$('map-message').textContent=params[bay].alert?`Preview stopped before space ${bay}: the sensor reports ALERT.`:`Car arrived at space ${bay} along the BFS route.`;}}
  motion=requestAnimationFrame(frame);
}
function activeButton(){document.querySelectorAll('[data-mode]').forEach(b=>{let yes=b.dataset.mode===mode;b.classList.toggle('active',yes);b.setAttribute('aria-pressed',String(yes));b.querySelector('.alg-go').textContent=yes?'✓ Shown':'Run ↗';});}
function failure(message){$('explanation').innerHTML=`<div class="empty-explanation"><strong>Could not run the algorithm</strong><p>${escapeHtml(message)}</p></div>`;$('engine-status').textContent='Engine unavailable';$('engine-dot').className='engine-dot error';}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(endpoint,payload){const res=await fetch('/api/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const obj=await res.json();if(!res.ok)throw Error(obj.error||'Server returned '+res.status);$('engine-dot').className='engine-dot ready';$('engine-status').textContent='AI engine online';return obj;}
function calculationDetails(lines){return `<details class="calculation"><summary>Show the actual calculations</summary><pre>${escapeHtml(lines.join('\n'))}</pre></details>`;}
function selectBay(name){if(!layout || !Object.hasOwn(layout.spots,name))return;bay=name;document.querySelectorAll('[data-spot]').forEach(b=>{b.classList.toggle('selected',b.dataset.spot===bay);b.setAttribute('aria-pressed',String(b.dataset.spot===bay));});$('spot-picked').textContent=`Space ${bay} selected`;clearMotion();drawBays();$('map-message').textContent=`Space ${bay} selected. Click an algorithm to see its result.`;if(mode)run(mode);}
async function run(nextMode){mode=nextMode;activeButton();let id=++sequence;clearMotion();drawBays();$('explanation').innerHTML='<div class="empty-explanation"><strong>Calculating…</strong><p>Running the Python algorithm for space '+bay+'.</p></div>';try{if(mode==='bfs'){const r=await api('bfs',{spot:bay,map:mapId});if(id!==sequence)return;renderBfs(r);}else if(mode==='bayes'){const r=await api('bayes',{spot:bay,map:mapId,prior:params[bay].prior,alert:params[bay].alert});if(id!==sequence)return;lastBayes[bay]=r.posterior;renderBayes(r);}else if(mode==='mdp'){const posterior=lastBayes[bay]??params[bay].prior;const source=lastBayes[bay]!==undefined?'Bayes updated probability':'Initial prior (Bayes not run yet)';const r=await api('mdp',{spot:bay,map:mapId,prob_occupied:posterior});if(id!==sequence)return;renderMdp(r,source);}}catch(e){if(id===sequence)failure(e.message);}}
function renderBfs(r){lastBfs=r;if(!r.path){$('map-message').textContent='No route to space '+bay+' on this map.';$('explanation').innerHTML='<div class="empty-explanation"><strong>No reachable route</strong><p>BFS checked all available road cells. Select a different parking space.</p></div>';return;}drawRoute(r.path);$('map-message').textContent=`BFS found ${r.distance} road segments to space ${bay}. Press Play to animate.`;const cells=r.path.map(c=>`(${c[0]},${c[1]})`).join(' → ');$('explanation').innerHTML=`<div class="result-eyebrow">01 • PATH SEARCH</div><div class="result-header"><h3>BFS: shortest route</h3><span class="result-pill">Complete</span></div><div class="result-number">${r.distance} steps</div><p class="result-caption">Shortest road to Space ${bay} • ${r.visited_count} cells checked</p><div class="explain-simple"><strong>Simple explanation:</strong> BFS checks nearby road cells first, so it finds the shortest route around obstacles.</div><div class="action-row"><button class="primary" id="drive-action" type="button">▶ Play car movement</button><span class="inline-hint">Blue line = calculated route</span></div>${calculationDetails([`Start: (${r.start.join(',')})`,`Goal: (${r.goal.join(',')})`,`Visited (BFS): ${r.visited_count} cells`,`Path: ${cells}`,`Route length: ${r.distance} moves`])}`;$('drive-action').addEventListener('click',driveCar);}
function renderBayes(r){$('map-message').textContent=`Bayes checked space ${bay}: occupancy probability is now ${pct(r.posterior)}.`;const priorPct=Math.round(params[bay].prior*100);$('explanation').innerHTML=`<div class="result-eyebrow">02 • UNCERTAINTY</div><div class="result-header"><h3>Bayes: is it taken?</h3><span class="result-pill ${r.posterior>=.5?'warn':''}">${r.alert?'ALERT':'CLEAR'} reading</span></div><div class="sensor-title">Change the simulated sensor</div><div class="sensor-buttons"><button id="sensor-clear" type="button" class="${!params[bay].alert?'active':''}">✓ Looks free</button><button id="sensor-alert" type="button" class="alert ${params[bay].alert?'active':''}">! Looks taken</button></div><label for="prior-slider" class="slider-label"><span>Chance before sensor (prior)</span><strong id="prior-display">${priorPct}%</strong></label><input class="prior-slider" id="prior-slider" type="range" min="1" max="99" value="${priorPct}"><div class="result-number">${pct(r.posterior)}</div><p class="result-caption">Updated probability that Space ${bay} is occupied</p><div class="prob-track"><div class="prob-fill" style="width:${(r.posterior*100).toFixed(2)}%"></div></div><div class="explain-simple"><strong>Simple explanation:</strong> Bayes combines what we believed before (${priorPct}%) with the ${r.alert?'alert':'clear'} sensor signal to calculate a better estimate.</div>${calculationDetails([`Prior P(occupied): ${num(r.prior)}`,`Sensor P(signal | occupied): ${num(r.likelihood_occupied)}`,`Sensor P(signal | free): ${num(r.likelihood_free)}`,`Posterior = (${num(r.likelihood_occupied)} × ${num(r.prior)}) / [(${num(r.likelihood_occupied)} × ${num(r.prior)}) + (${num(r.likelihood_free)} × ${num(1-r.prior)})]`,`P(occupied | ${r.alert?'alert':'clear'}): ${num(r.posterior)}`])}`;
  $('sensor-clear').addEventListener('click',()=>changeSensor(false));$('sensor-alert').addEventListener('click',()=>changeSensor(true));$('prior-slider').addEventListener('input',e=>{params[bay].prior=Number(e.target.value)/100;$('prior-display').textContent=e.target.value+'%';lastBayes[bay]=undefined;clearTimeout(window.__priorTimer);window.__priorTimer=setTimeout(()=>run('bayes'),110);});}
function changeSensor(alert){params[bay].alert=alert;delete lastBayes[bay];drawBays();run('bayes');}
function renderMdp(r,source){const d=r.expected.DRIVE,q=r.expected.RECHECK,choose=r.action;const probability=pct(r.prob_occupied);$('map-message').textContent=`MDP recommends ${choose==='DRIVE'?'DRIVE':'RECHECK'} for space ${bay}, based on ${probability} occupancy.`;$('explanation').innerHTML=`<div class="result-eyebrow">03 • DECISION MAKING</div><div class="result-header"><h3>MDP: choose an action</h3><span class="result-pill ${choose==='RECHECK'?'warn':''}">${choose}</span></div><div class="result-number">${choose==='DRIVE'?'Drive':'Check again'}</div><p class="result-caption">For Space ${bay} • chance occupied: ${probability}</p><div class="score-grid"><div class="score ${choose==='DRIVE'?'winner':''}"><strong>DRIVE score</strong><b>${num(d)}</b><small>utility points</small></div><div class="score ${choose==='RECHECK'?'winner':''}"><strong>RECHECK score</strong><b>${num(q)}</b><small>utility points</small></div></div><div class="explain-simple"><strong>Simple explanation:</strong> MDP compares the expected rewards of two actions and chooses the bigger score. ${choose==='DRIVE'?'Driving has the higher expected value.':'Another check is safer according to these sample rewards.'}</div><p class="inline-hint">Input: ${escapeHtml(source)} (${probability}).</p>${calculationDetails([`Input P(occupied): ${calcNum(r.prob_occupied)}`,`Input P(free): ${calcNum(1-r.prob_occupied)}`,`Q(DRIVE | free): ${num(r.state_action_values.DRIVE.FREE)}`,`Q(DRIVE | occupied): ${num(r.state_action_values.DRIVE.OCCUPIED)}`,`Q(RECHECK | free): ${num(r.state_action_values.RECHECK.FREE)}`,`Q(RECHECK | occupied): ${num(r.state_action_values.RECHECK.OCCUPIED)}`,`Expected DRIVE: ${calcNum(1-r.prob_occupied)} × ${num(r.state_action_values.DRIVE.FREE)} + ${calcNum(r.prob_occupied)} × ${num(r.state_action_values.DRIVE.OCCUPIED)} = ${num(d)}`,`Expected RECHECK: ${calcNum(1-r.prob_occupied)} × ${num(r.state_action_values.RECHECK.FREE)} + ${calcNum(r.prob_occupied)} × ${num(r.state_action_values.RECHECK.OCCUPIED)} = ${num(q)}`,`Chosen action: ${choose} (higher expected score)`,`Probabilities shown with 10 decimals; utility results rounded to 2 decimals.`])}`;}
function setMap(nextMap,{initial=false}={}){
  if(!Object.hasOwn(maps,nextMap))return;
  sequence++; mapId=nextMap;layout=maps[nextMap];
  params=Object.fromEntries(Object.entries(layout.spots).map(([key,d])=>[key,{prior:d.prior,alert:d.alert}]));
  lastBayes={};bay='A';mode=null;
  clearMotion();buildMap();activeButton();
  document.querySelectorAll('[data-map]').forEach(b=>{const is=b.dataset.map===mapId;b.classList.toggle('active',is);b.setAttribute('aria-pressed',String(is));});
  document.querySelectorAll('[data-spot]').forEach(b=>{const is=b.dataset.spot==='A';b.classList.toggle('selected',is);b.setAttribute('aria-pressed',String(is));});
  $('spot-picked').textContent='Space A selected';
  $('explanation').innerHTML='<div class="empty-explanation"><div class="empty-icon">↗</div><strong>Choose an algorithm</strong><p>Click BFS, Bayes or MDP. Each button runs a separate AI calculation for the selected parking space.</p></div>';
  $('map-message').textContent=`${layout.name} map ready. Select A, B or C, then run any algorithm.`;
}
function resetAll(){setMap('mall');}
async function initialize(){
  try{
    const res=await fetch('/api/maps');if(!res.ok)throw Error('Server offline');const data=await res.json();
    maps=Object.fromEntries(data.maps.map(item=>[item.id,item]));
    setMap('mall',{initial:true});
    $('engine-status').textContent='AI engine online';$('engine-dot').className='engine-dot ready';
  }catch(e){failure('Please start run_windows.bat. The local Python server is not running.');}
}
document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>{if(layout)run(b.dataset.mode);}));
document.querySelectorAll('[data-spot]').forEach(b=>b.addEventListener('click',()=>selectBay(b.dataset.spot)));
document.querySelectorAll('[data-map]').forEach(b=>b.addEventListener('click',()=>setMap(b.dataset.map)));
$('reset-btn').addEventListener('click',resetAll);
initialize();
