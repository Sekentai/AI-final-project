# ParkPilot — Simple Demo and Defense Script (English)

This script matches **ParkPilot v4**. Speak naturally rather than memorizing every word.

## Introduction (about 1 minute)

"Our project is ParkPilot, an interactive parking simulation that demonstrates three fundamental AI methods. Parking systems need to solve different problems: finding a route, interpreting uncertain sensor signals, and deciding what action is sensible. We use Breadth-First Search for the shortest path, Bayesian inference for occupancy probability, and a one-step Markov Decision Process for deciding whether to drive or recheck. The data here are hypothetical, and we do not claim real parking information."

## Live demo (3–5 minutes)

**1. BFS — click the BFS button.**

"This is our parking lot. Space A is selected. When I click BFS, the Python server calculates the shortest route using a first-in, first-out queue. The blue line shows the result: four road steps from our car to Space A. These planters are obstacles. Now I click Play car movement: the car follows the path BFS actually found. We can open the calculation to see the sequence of grid coordinates."

**2. Bayes — click Bayes.**

"Our sensor is not always right. Initially, Space A has a 25 percent probability of being occupied. A CLEAR signal reduces our estimate to 5.3 percent using Bayes' theorem. If I click Looks taken, the probability goes up to 73.9 percent. I can also change the prior with the slider. Bayes uses one prior, one sensor reading, and the assumed sensor accuracy."

**3. MDP — click MDP.**

"Now I ask AI what action to take. The MDP takes the latest Bayesian probability. It compares two actions, DRIVE and RECHECK, using fixed transition probabilities, rewards, and a one-step Bellman update. With a high occupancy risk, the value for RECHECK is higher. The chosen action and both scores appear here."

**4. Repeat for another bay.**

"I'll click Space C and then Bayes. It gives 20 percent occupancy from its CLEAR reading. When I click MDP, DRIVE has a higher expected score. I can separately click BFS to see that Space C needs five road steps. The three buttons are independent, but they solve parts of one parking problem."

## Algorithm explanations for individual questions

- **BFS input:** map, start, target and blocked cells. **Steps:** FIFO queue, expand 4 neighbors, mark predecessors, reconstruct path. **Output:** shortest path, step count and explored cells. **Why BFS:** all grid moves have equal cost.
- **Bayes input:** prior occupancy probability, alert/clear signal, sensitivity and specificity. **Formula:** posterior = likelihood × prior / total evidence. **Output:** P(occupied | reading). **Why Bayes:** sensors can produce false positives and false negatives.
- **MDP input:** occupancy belief, states FREE/OCCUPIED, actions DRIVE/RECHECK, rewards, transitions and discounted continuation values. **Steps:** one Bellman update per state/action, then belief-weighted expected score. **Output:** better action. **Why MDP:** the best action depends on risk and rewards, not just physical distance.

## Common Q&A

**Is this a real AI or just a drawing?**
The road route, posterior probability and expected action values are calculated by three real Python algorithm implementations. The map and animation make those calculations easier to see. The sensor inputs themselves are simulated.

**Why three different algorithms?**
They solve three different subproblems: BFS handles navigation, Bayes handles uncertain evidence, and MDP handles choices under uncertainty.

**Does clicking a button run only that algorithm?**
Yes. BFS calls `/api/bfs`, Bayes calls `/api/bayes`, and MDP calls `/api/mdp`. The backend also provides `/api/analyze`, which integrates all three for overall recommendations.

**What if MDP is clicked before Bayes?**
It uses the chosen space's default prior and explicitly labels it. After Bayes runs, MDP uses the updated probability.

**What are the limitations?**
This is a 5×5 static map with imaginary sensors and rewards, plus a single-step MDP. In a real project we would need observed sensor data, more accurate movement costs and longer-horizon decision planning.

**How was AI used in development?**
ChatGPT substantially assisted with code, interface, documentation and test generation. The AI Use Declaration lists this assistance. We remain responsible for reviewing and understanding the work.

## Recording your own video

In a 2–3 minute recording, show the main page, press **BFS**, play the blue car animation, press **Bayes**, change CLEAR to ALERT, press **MDP**, then click **Space C** and repeat Bayes/MDP. Conclude that each algorithm makes a different contribution to one scenario. Record the video yourself as required by the assignment.


## Three-map update (v5)
The website has tabs **Mall**, **Campus**, and **Stadium**. To demonstrate the different search settings, switch the tab, select a parking bay and click **BFS**. Show that the start, obstacles, path and step count change. Bayes and MDP are still separate buttons and use the chosen map's simulated sensor inputs. Switching maps resets stale results.
