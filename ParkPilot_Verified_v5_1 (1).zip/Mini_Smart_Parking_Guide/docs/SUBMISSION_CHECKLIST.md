# Submission checklist — ParkPilot v4

- [x] Working local Python application and graphical parking simulation.
- [x] Three **separate** visible algorithm controls: BFS, Bayes, MDP, with independent Python endpoints.
- [x] Every algorithm shows input, calculation, output and simple-English explanation.
- [x] Optional smoothly animated car along the BFS route.
- [x] 19 Python tests passed; separate API endpoints and browser UI smoke test passed.
- [x] Source code and README.
- [x] Technical Report (docs/Technical_Report.docx).
- [x] Seven-slide Presentation (docs/Presentation.pptx).
- [x] AI Use Declaration form (docs/AI_Use_Declaration.docx).
- [x] Team Contribution Statement form (docs/Team_Contribution_Statement.docx).
- [x] Demo, questions and video script (docs/Demo_and_Defense_Script.md).
- [ ] Student(s): fill in real names, group, team contributions and AI-use acknowledgment truthfully.
- [ ] Independently run and understand the code, test claims and demonstration.
- [ ] Upload this folder to your own GitHub repository and include its URL in the submission.
- [ ] Make your **own 2–3-minute demo video** and prepare for individual Q&A.

Do not claim a GitHub repository or video has already been created. The simulated sensor data and parameters are not from any real parking facility.


## Three-map update (v5)
The website has tabs **Mall**, **Campus**, and **Stadium**. To demonstrate the different search settings, switch the tab, select a parking bay and click **BFS**. Show that the start, obstacles, path and step count change. Bayes and MDP are still separate buttons and use the chosen map's simulated sensor inputs. Switching maps resets stale results.
