"""Explainable mini AI parking agent: BFS + Bayesian inference + one-step MDP.

All data in this file are deliberately simulated for an AI Fundamentals course.
No trained model, external data source, or third-party packages are required.
"""
from collections import deque
from typing import Tuple

GRID_SIZE = 5
# Three independently testable, hypothetical parking layouts.
# All scenarios use the same 5x5 graph and identical Bayes/MDP mathematics.
MAPS = {
    'mall': {
        'name': 'Shopping centre', 'label': 'P1 · Mall', 'description': 'A direct lane with three planted islands.',
        'start': (4, 0), 'walls': {(1, 1), (2, 1), (3, 3)},
        'spots': {
            'A': {'position': (0, 0), 'prior': 0.25, 'alert': False},
            'B': {'position': (0, 4), 'prior': 0.45, 'alert': True},
            'C': {'position': (3, 4), 'prior': 0.60, 'alert': False},
        },
    },
    'campus': {
        'name': 'University campus', 'label': 'P2 · Campus', 'description': 'Approach from the right; avoid the central walkways.',
        'start': (4, 4), 'walls': {(1, 2), (2, 2), (3, 1)},
        'spots': {
            'A': {'position': (0, 4), 'prior': 0.62, 'alert': True},
            'B': {'position': (0, 0), 'prior': 0.20, 'alert': False},
            'C': {'position': (3, 0), 'prior': 0.50, 'alert': False},
        },
    },
    'stadium': {
        'name': 'Stadium', 'label': 'P3 · Stadium', 'description': 'Event-day parking with a blocked central approach.',
        'start': (4, 2), 'walls': {(1, 2), (2, 2), (3, 3), (2, 0)},
        'spots': {
            'A': {'position': (0, 1), 'prior': 0.35, 'alert': False},
            'B': {'position': (0, 4), 'prior': 0.70, 'alert': True},
            'C': {'position': (3, 0), 'prior': 0.40, 'alert': False},
        },
    },
}
# Preserve original constants for backwards-compatible educational examples.
START = MAPS['mall']['start']
WALLS = MAPS['mall']['walls']
SPOTS = MAPS['mall']['spots']


def get_map(map_id='mall'):
    if not isinstance(map_id, str) or map_id not in MAPS:
        raise ValueError('map must be mall, campus or stadium')
    return MAPS[map_id]


def map_catalog():
    """API-safe map data, with tuple coordinates converted into JSON lists."""
    return {'maps': [
        {
            'id': map_id, 'name': layout['name'], 'label': layout['label'],
            'description': layout['description'], 'start': list(layout['start']),
            'walls': [list(p) for p in sorted(layout['walls'])],
            'spots': {name: {'position': list(info['position']), 'prior': info['prior'],
                             'alert': info['alert']} for name, info in layout['spots'].items()},
        }
        for map_id, layout in MAPS.items()
    ]}

SENSITIVITY = 0.85  # P(alert | occupied)
SPECIFICITY = 0.90  # P(clear | free)
DISCOUNT = 0.60
ROUTE_COST = 0.70  # a hypothetical travel penalty per grid step

# Modelled states are FREE and OCCUPIED; actions are DRIVE and RECHECK.
# Hypothetical transitions may reflect a spot changing between scans and arrival.
# Every transition row sums to 1.0.
TRANSITIONS = {
    'DRIVE': {
        'FREE': {'FREE': 0.95, 'OCCUPIED': 0.05},
        'OCCUPIED': {'FREE': 0.10, 'OCCUPIED': 0.90},
    },
    'RECHECK': {
        'FREE': {'FREE': 0.85, 'OCCUPIED': 0.15},
        'OCCUPIED': {'FREE': 0.35, 'OCCUPIED': 0.65},
    },
}
REWARDS = {
    'DRIVE': {'FREE': 12.0, 'OCCUPIED': -12.0},
    'RECHECK': {'FREE': -2.0, 'OCCUPIED': -2.0},
}
# These continuation values are set by the model, not learned from data.
STATE_VALUES = {'FREE': 4.0, 'OCCUPIED': -4.0}


def bfs(start: Tuple[int, int], goal: Tuple[int, int], walls=None, size=GRID_SIZE):
    """Return (shortest path including endpoints, visited-order). None if unreachable."""
    walls = WALLS if walls is None else set(walls)
    if (not (0 <= start[0] < size and 0 <= start[1] < size) or
            not (0 <= goal[0] < size and 0 <= goal[1] < size) or
            start in walls or goal in walls):
        return None, []
    queue = deque([start]); previous = {start: None}; expanded = []
    while queue:
        current = queue.popleft()
        expanded.append(current)
        if current == goal:
            path = []
            while current is not None:
                path.append(current); current = previous[current]
            return path[::-1], expanded
        r, c = current
        # Fixed neighbor order ensures reproducible shortest paths.
        for neighbor in ((r-1, c), (r, c+1), (r+1, c), (r, c-1)):
            nr, nc = neighbor
            if 0 <= nr < size and 0 <= nc < size and neighbor not in walls and neighbor not in previous:
                previous[neighbor] = current
                queue.append(neighbor)
    return None, expanded


def bayesian_occupancy(prior: float, alert: bool, sensitivity=SENSITIVITY, specificity=SPECIFICITY):
    """Bayes P(O|signal) with transparent intermediate numerators."""
    if not 0.0 <= prior <= 1.0:
        raise ValueError('Prior must be in [0,1].')
    if not 0.0 <= sensitivity <= 1.0 or not 0.0 <= specificity <= 1.0:
        raise ValueError('Sensitivity and specificity must be in [0,1].')
    likelihood_occupied = sensitivity if alert else 1.0-sensitivity
    likelihood_free = 1.0-specificity if alert else specificity
    numerator = likelihood_occupied * prior
    alternative = likelihood_free * (1.0-prior)
    evidence = numerator + alternative
    if evidence == 0:
        raise ValueError('This observation is impossible with these parameters.')
    return {
        'posterior': numerator / evidence,
        'likelihood_occupied': likelihood_occupied,
        'likelihood_free': likelihood_free,
        'numerator': numerator,
        'alternative': alternative,
        'evidence': evidence,
    }


def one_step_mdp(prob_occupied: float):
    """Calculate a Bellman update and belief-weighted action value.

    Q(s,a) = R(s,a) + gamma * sum_s' P(s'|s,a) V(s')
    E[Q(a)|observation] = (1-p)Q(FREE,a) + p Q(OCCUPIED,a).
    """
    if not 0.0 <= prob_occupied <= 1.0:
        raise ValueError('Belief must be in [0,1].')
    q_state = {}; expected = {}
    for action in ('DRIVE', 'RECHECK'):
        q_state[action] = {}
        for state in ('FREE', 'OCCUPIED'):
            continuation = sum(TRANSITIONS[action][state][next_state] * STATE_VALUES[next_state]
                               for next_state in ('FREE', 'OCCUPIED'))
            q_state[action][state] = REWARDS[action][state] + DISCOUNT * continuation
        expected[action] = ((1.0-prob_occupied) * q_state[action]['FREE'] +
                            prob_occupied * q_state[action]['OCCUPIED'])
    return {
        'state_action_values': q_state,
        'expected': expected,
        'action': max(('DRIVE', 'RECHECK'), key=lambda a: expected[a]),
    }


def analyze(payload=None):
    """Run the same three algorithms for the requested parking map.

    Optional payload: {"map":"campus","spots":{"A":{"alert":false}},"selected":"A"}
    """
    payload = payload or {}
    layout_id = payload.get('map', 'mall')
    layout = get_map(layout_id)
    spots = layout['spots']; start = layout['start']; walls = layout['walls']
    provided = payload.get('spots', {})
    if not isinstance(provided, dict):
        raise ValueError('spots must be an object.')
    selected = payload.get('selected', 'A')
    if selected not in spots:
        raise ValueError('selected must be A, B or C.')
    calculated = {}
    for name, default in spots.items():
        raw = provided.get(name, {})
        if not isinstance(raw, dict):
            raise ValueError(f'Spot {name} must be an object.')
        prior = float(raw.get('prior', default['prior']))
        signal = raw.get('alert', default['alert'])
        if not isinstance(signal, bool):
            raise ValueError('alert must be true or false.')
        bayes = bayesian_occupancy(prior, signal)
        # Other parking spaces cannot be used as through-lanes.
        other_bays = {info['position'] for other, info in spots.items() if other != name}
        path, expanded = bfs(start, default['position'], walls | other_bays)
        mdp = one_step_mdp(bayes['posterior'])
        distance = len(path)-1 if path is not None else None
        drive_score = mdp['expected']['DRIVE'] - ROUTE_COST*distance if distance is not None else None
        calculated[name] = {
            'name': name, 'position': list(default['position']), 'prior': prior,
            'alert': signal, 'path': [list(p) for p in path] if path else None,
            'distance': distance, 'visited_count': len(expanded),
            'visited_order': [list(c) for c in expanded],
            'bayes': bayes, 'mdp': mdp, 'drive_score': drive_score,
        }
    eligible = [s for s in calculated.values() if s['distance'] is not None and s['mdp']['action'] == 'DRIVE']
    if eligible:
        best = max(eligible, key=lambda s: (s['drive_score'], -s['distance']))
        recommendation = {
            'spot': best['name'], 'action': 'DRIVE', 'score': best['drive_score'],
            'reason': 'Highest DRIVE value minus route cost among reachable DRIVE options.',
        }
    else:
        viable = [s for s in calculated.values() if s['distance'] is not None]
        if viable:
            best = max(viable, key=lambda s: s['mdp']['expected']['RECHECK'])
            recommendation = {'spot': best['name'], 'action': 'RECHECK',
                              'score': best['mdp']['expected']['RECHECK'],
                              'reason': 'All reachable spots need another sensor check before driving.'}
        else:
            recommendation = {'spot': None, 'action': 'UNREACHABLE', 'score': None,
                              'reason': 'No parking spot is reachable on this map.'}
    return {
        'map': layout_id, 'map_name': layout['name'],
        'grid_size': GRID_SIZE, 'start': list(start), 'walls': [list(p) for p in sorted(walls)],
        'sensitivity': SENSITIVITY, 'specificity': SPECIFICITY,
        'discount': DISCOUNT, 'route_cost': ROUTE_COST,
        'state_values': STATE_VALUES, 'transitions': TRANSITIONS, 'rewards': REWARDS,
        'spots': calculated, 'selected': selected, 'recommendation': recommendation,
        'simulation_notice': 'Teaching simulation. Map layouts, sensor rates, priors, rewards and transitions are hypothetical.',
    }

if __name__ == '__main__':
    import json
    print(json.dumps(analyze(), indent=2))
